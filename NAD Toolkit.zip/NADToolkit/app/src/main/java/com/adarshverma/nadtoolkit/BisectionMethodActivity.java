package com.adarshverma.nadtoolkit;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;

public class BisectionMethodActivity extends AppCompatActivity {
    public static String equation;
    String initA;
    String initB;
    String error;
    String result;
    EditText equationEntryField;
    TextView rootTextView;
    EditText initialAEntryField;
    EditText initialBEntryField;
    EditText errorEntryField;
    ArrayList<Iteration> iterations = new ArrayList<>();
    boolean empty;
    ArrayAdapter<Iteration> iterationAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bisection_method);
        equationEntryField = (EditText) findViewById(R.id.equation_entry_field_id);
        initialAEntryField = (EditText) findViewById(R.id.initA);
        initialBEntryField = (EditText) findViewById(R.id.initB);
        errorEntryField = (EditText) findViewById(R.id.error);
        rootTextView = (TextView) findViewById(R.id.root_text_view);
        errorEntryField.setText("0.001");


    }


    double f(String equation, double x) {
        String valueString = Double.toString(x);
        equation = equation.replace("x", valueString);
        return eval(equation);
    }

    void bisectionMethod(String equation, double a, double b, double e) {


        if (f(equation, a) * f(equation, b) >= 0) {
            Toast.makeText(this, "Initial Values doesn't satisfies the equation,try different values!", Toast.LENGTH_LONG).show();
            return;
        }

        double mid = (b + a) / 2;
        int i = 0;
        while (Math.abs((b - a)) >= e) {
            mid = (a + b) / 2;
            iterations.add(new Iteration(i + 1, a, b, mid, f(equation, mid)));
            if (f(equation, mid) == 0.0)
                break;

            else if (f(equation, mid) * f(equation, a) < 0)
                b = mid;
            else
                a = mid;
            i++;
        }

        iterationAdapter = new IterationAdapter(this, iterations);
        ListView listView = (ListView) findViewById(R.id.a_list);
        listView.setAdapter(iterationAdapter);
        String root = Double.toString(mid);
        result = "Root: " + root;
        rootTextView.setText(result);

        closeKeyboard();


    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public void calculate(View view) {


        checkEmptyFields();
        iterations.clear();

        if (!empty) {
try {
    equation = equationEntryField.getText().toString();
    initA = initialAEntryField.getText().toString();
    initB = initialBEntryField.getText().toString();
    error = errorEntryField.getText().toString();
    double a = Double.parseDouble(initA);
    double b = Double.parseDouble(initB);
    double e = Double.parseDouble(error);
    bisectionMethod(equation, a, b, e);
}
catch (Exception e){
    Toast.makeText(this, "Please check your inputs.\nNote:Equation should be in x", Toast.LENGTH_SHORT).show();
}
        }

        //equationTextView.setText(Double.toString(g));
    }

    public void checkEmptyFields() {
        if (TextUtils.isEmpty(equationEntryField.getText())) {
            Toast.makeText(this, "Equation Field Empty!!", Toast.LENGTH_SHORT).show();
            empty = true;

        } else if (TextUtils.isEmpty(initialAEntryField.getText())) {
            Toast.makeText(this, "Please input initial value of a.", Toast.LENGTH_SHORT).show();
            empty = true;
        } else if (TextUtils.isEmpty(initialBEntryField.getText())) {
            Toast.makeText(this, "Please input initial value of b.", Toast.LENGTH_SHORT).show();
            empty = true;
        } else if (TextUtils.isEmpty(errorEntryField.getText())) {
            Toast.makeText(this, "Please set accuracy.", Toast.LENGTH_SHORT).show();

            empty = true;
        } else {
            empty = false;
        }

    }

    private static double eval(final String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char) ch);
                return x;
            }

            // Grammar:
            // expression = term | expression `+` term | expression `-` term
            // term = factor | term `*` factor | term `/` factor
            // factor = `+` factor | `-` factor | `(` expression `)`
            //        | number | functionName factor | factor `^` factor

            double parseExpression() {
                double x = parseTerm();
                for (; ; ) {
                    if (eat('+')) x += parseTerm(); // addition
                    else if (eat('-')) x -= parseTerm(); // subtraction
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (; ; ) {
                    if (eat('*')) x *= parseFactor(); // multiplication
                    else if (eat('/')) x /= parseFactor(); // division
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor(); // unary plus
                if (eat('-')) return -parseFactor(); // unary minus

                double x;
                int startPos = this.pos;
                if (eat('(')) { // parentheses
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') { // numbers
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else if (ch >= 'a' && ch <= 'z') { // functions
                    while (ch >= 'a' && ch <= 'z') nextChar();
                    String func = str.substring(startPos, this.pos);
                    x = parseFactor();
                    if (func.equals("sqrt")) x = Math.sqrt(x);
                    else if (func.equals("sin")) x = Math.sin(Math.toRadians(x));
                    else if (func.equals("cos")) x = Math.cos(Math.toRadians(x));
                    else if (func.equals("tan")) x = Math.tan(Math.toRadians(x));
                    else throw new RuntimeException("Unknown function: " + func);
                } else {
                    throw new RuntimeException("Unexpected: " + (char) ch);
                }

                if (eat('^')) x = Math.pow(x, parseFactor()); // exponentiation

                return x;
            }
        }.parse();
    }
}
